
let startTime, duration, endTime, timer, isPaused = false, pausedAt;

const countdownEl = document.getElementById("fasting-countdown");
const startEl = document.getElementById("fasting-start");
const endEl = document.getElementById("fasting-end");
const pauseBtn = document.getElementById("pause-fast");
const resumeBtn = document.getElementById("resume-fast");
const resetBtn = document.getElementById("reset-fast");

let fastChart, durationChart;

function notify(title, body) {
  if (Notification.permission === "granted") {
    new Notification(title, { body });
  }
}

function saveState() {
  localStorage.setItem("fastingState", JSON.stringify({ startTime, duration, isPaused, pausedAt }));
}

function loadState() {
  const state = JSON.parse(localStorage.getItem("fastingState"));
  if (state?.startTime && state?.duration) {
    startTime = new Date(state.startTime);
    duration = state.duration;
    isPaused = state.isPaused;
    pausedAt = state.pausedAt ? new Date(state.pausedAt) : null;
    startCountdown();
  }
}

function updateCountdown() {
  if (!startTime || !duration || isPaused) return;
  const now = new Date();
  const diff = Math.max(0, endTime - now);
  const hrs = String(Math.floor(diff / 3600000)).padStart(2, "0");
  const mins = String(Math.floor((diff % 3600000) / 60000)).padStart(2, "0");
  const secs = String(Math.floor((diff % 60000) / 1000)).padStart(2, "0");
  countdownEl.textContent = `${hrs}:${mins}:${secs}`;
  countdownEl.style.color = diff < 60000 ? "#e53935" : "#1976d2";

  if (diff === 0) {
    clearInterval(timer);
    localStorage.removeItem("fastingState");
    notify("Fasting Complete", "Your fast has ended.");
  }
}

function startCountdown() {
  endTime = new Date(startTime.getTime() + duration);
  startEl.textContent = startTime.toLocaleString();
  endEl.textContent = endTime.toLocaleString();
  updateCountdown();
  clearInterval(timer);
  timer = setInterval(updateCountdown, 1000);
  saveState();
}

document.getElementById("log-form").addEventListener("submit", async e => {
  e.preventDefault();
  const type = document.getElementById("fast-type").value;
  const note = document.getElementById("log-note").value;
  const durations = {
    "12-hour": 12, "16:8": 16, "18:6": 18,
    "20:4": 20, "OMAD": 23, "36-hour": 36,
    "48-hour": 48, "3-Day": 72
  };
  duration = durations[type] * 3600000;
  startTime = new Date();
  isPaused = false;
  pausedAt = null;
  startCountdown();

  await fetch("/log", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type, note, durationHours: durations[type] })
  });

  fetchLogs();
});

pauseBtn.addEventListener("click", () => {
  isPaused = true;
  pausedAt = new Date();
  pauseBtn.style.display = "none";
  resumeBtn.style.display = "inline";
  saveState();
});

resumeBtn.addEventListener("click", () => {
  const pauseDuration = new Date() - pausedAt;
  startTime = new Date(startTime.getTime() + pauseDuration);
  pausedAt = null;
  isPaused = false;
  pauseBtn.style.display = "inline";
  resumeBtn.style.display = "none";
  startCountdown();
});

resetBtn.addEventListener("click", () => {
  clearInterval(timer);
  localStorage.removeItem("fastingState");
  startTime = duration = endTime = null;
  startEl.textContent = endEl.textContent = countdownEl.textContent = "--";
});

async function fetchLogs() {
  const res = await fetch("/log");
  const logs = await res.json();
  const list = document.getElementById("log-history");
  const durationList = document.getElementById("duration-history");
  list.innerHTML = "";
  durationList.innerHTML = "";

  let labels = [], data = [];

  logs.forEach(l => {
    const li = document.createElement("li");
    li.textContent = `${new Date(l.date).toLocaleDateString()} – ${l.type} (${l.note || ''})`;
    list.appendChild(li);

    const dli = document.createElement("li");
    dli.textContent = `${l.durationHours} hrs on ${new Date(l.date).toLocaleDateString()}`;
    durationList.appendChild(dli);

    labels.push(new Date(l.date).toLocaleDateString());
    data.push(l.durationHours);
  });

  if (window.fastChart) window.fastChart.destroy();
  if (window.durationChart) window.durationChart.destroy();

  const ctx1 = document.getElementById("fastChart").getContext("2d");
  const ctx2 = document.getElementById("durationChart").getContext("2d");

  window.fastChart = new Chart(ctx1, {
    type: 'bar',
    data: { labels, datasets: [{ label: 'Fasts', data }] }
  });

  window.durationChart = new Chart(ctx2, {
    type: 'line',
    data: { labels, datasets: [{ label: 'Duration (hrs)', data }] }
  });
}

document.getElementById("export-csv").addEventListener("click", async () => {
  const res = await fetch("/log");
  const logs = await res.json();
  const csv = ["Date,Type,Note,Duration"];
  logs.forEach(l => {
    csv.push(`${l.date},${l.type},${l.note},${l.durationHours}`);
  });
  const blob = new Blob([csv.join("\n")], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "fasting_log.csv";
  a.click();
});

document.getElementById("export-pdf").addEventListener("click", async () => {
  const res = await fetch("/log");
  const logs = await res.json();
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.text("Fasting Log", 10, 10);
  doc.autoTable({
    startY: 20,
    head: [["Date", "Type", "Note", "Duration"]],
    body: logs.map(l => [l.date, l.type, l.note || "", l.durationHours])
  });
  doc.save("fasting_log.pdf");
});

window.onload = () => {
  Notification.requestPermission();
  loadState();
  fetchLogs();
};
